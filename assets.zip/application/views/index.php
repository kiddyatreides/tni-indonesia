
<?php

$tgl=date('l, d-m-Y');

{ ?>
<h1> Dashboard</h1><h3> <?php echo $tgl;?></h3>

<?php } ?>
<div class="bs-example4" data-example-id="contextual-table">
	<!-- isi disini-->
	<div class="col_3">
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-thumbs-up icon-rounded"></i>
                    <div class="stats">
                      <h5><strong>45</strong></h5>
                      <span>Permintaan</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-users user1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong>10</strong></h5>
                      <span>Pesan</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-comment user2 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong>2</strong></h5>
                      <span>Feedback</span>
                    </div>
                </div>
        	</div>
        	
        	<div class="clearfix"> </div>
      </div>
	<!-- diatas ini-->
</div>
